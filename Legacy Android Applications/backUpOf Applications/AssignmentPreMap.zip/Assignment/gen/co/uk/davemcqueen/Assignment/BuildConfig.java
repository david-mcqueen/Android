/** Automatically generated file. DO NOT MODIFY */
package co.uk.davemcqueen.Assignment;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}