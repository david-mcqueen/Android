package co.uk.davemcqueen.Assignment;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBHelper extends SQLiteOpenHelper {
	
	private static final String TAG = "DBHelper";
	
	private static final String DBName = "diary.db";
	private static final int DBVersion = 1;
	
	public static final String TABLE_EVENTS = "events";
	public static final String COLUMN_ID = "_id";
	public static final String COLUMN_EVENT = "eventName";
	public static final String COLUMN_DESCRIPTION = "eventDescription";
	public static final String COLUMN_DATE = "eventDate";
	public static final String COLUMN_TIME = "eventTime";
	public static final String COLUMN_LOCATION = "eventLocation";
	
	
	private static final String CreateDBTable = "CREATE TABLE "
			+ TABLE_EVENTS + " ("
			+ COLUMN_ID + " INTEGER PRIMARY KEY, "
			+ COLUMN_EVENT + " TEXT, "
			+ COLUMN_DESCRIPTION + " TEXT, "
			+ COLUMN_DATE + " TEXT, "
			+ COLUMN_TIME + " REAL, "
			+ COLUMN_LOCATION + " TEXT"
			+ ");";
		
	
	public DBHelper(Context context)
	{
	super (context, DBName, null, DBVersion);
	}
	
	public DBHelper(Context context, boolean testMode)
	{
		super(context, null, null, DBVersion);
	}
			
	@Override
	public void onCreate(SQLiteDatabase db) {
		// TODO Auto-generated method stub
		Log.w(TAG, CreateDBTable + " created");
		db.execSQL(CreateDBTable);
		
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub
	}
}
