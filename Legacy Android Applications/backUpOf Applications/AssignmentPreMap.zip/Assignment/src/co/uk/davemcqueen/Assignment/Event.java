package co.uk.davemcqueen.Assignment;

import android.content.ContentValues;
import android.provider.BaseColumns;

public class Event {
private long id;
private String event;
private String description;
private long date;
private String time;

public Event(ContentValues values)
{
	description = values.getAsString(Event.EventItem.COLUMN_NAME_DESCRIPTION);
}

public ContentValues getContentValues()
{
	ContentValues v = new ContentValues();
	v.put(Event.EventItem.COLUMN_NAME_ID, id);
	v.put(Event.EventItem.COLUMN_NAME_DESCRIPTION, description);
	v.put(Event.EventItem.COLUMN_NAME_EVENT, event);
	v.put(Event.EventItem.COLUMN_NAME_DATE, date);
	v.put(Event.EventItem.COLUMN_NAME_TIME, time);
	return v;
}

public static final class EventItem implements BaseColumns
{
	
private EventItem() {}

public static final String TABLE_NAME = "events";

private static final String Scheme = "content://";

private static final String PATH_EVENT = "/events";

private static final String PATH_EVENT_ID = "/events/";

public static final String COLUMN_NAME_DESCRIPTION = "eventDescription";

public static final String COLUMN_NAME_EVENT = "eventName";

public static final String COLUMN_NAME_DATE = "eventDate";

public static final String COLUMN_NAME_TIME = "eventTime";

public static final String COLUMN_NAME_ID = "_id";

public static final String COLUMN_NAME_LOCATION = "eventLocation";

public static final String DEFAULT_SORT_ORDER = Event.EventItem.COLUMN_NAME_DATE + " DESC";

}

}
