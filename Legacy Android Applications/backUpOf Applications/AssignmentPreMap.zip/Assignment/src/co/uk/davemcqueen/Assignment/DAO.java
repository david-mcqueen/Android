package co.uk.davemcqueen.Assignment;


import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;

public class DAO {

	private static final String TAG = "DAO";
	private DBHelper mDBHelper;
	
	public DAO(Context context)
	{
		
		mDBHelper = new DBHelper(context);
	}
	
	protected DAO(Context context, boolean testMode)
	{
		if(testMode)
		{
			mDBHelper = new DBHelper(context, testMode);
			
		}else{
			mDBHelper = new DBHelper(context);
		}
	}
	
	public Cursor queryEvents(String[] projection, String selection, String [] selectionArgs)
	{
		SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
		qb.setTables(Event.EventItem.TABLE_NAME); //Specify which table working with
		SQLiteDatabase db = mDBHelper.getReadableDatabase();
		
		
		Cursor c = qb.query(db, projection, selection, selectionArgs, null, null, Event.EventItem.COLUMN_NAME_DATE);
		db.close();
		
		return c;
	}
	//Returns all events in the DB
	public Cursor queryAllEvents(String[] projection)
	{
		SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
		qb.setTables(Event.EventItem.TABLE_NAME);
		SQLiteDatabase db = mDBHelper.getReadableDatabase();
		return qb.query(db, projection, null, null, null, null, Event.EventItem.COLUMN_NAME_DATE);
	}
	
	//Returns an event relevant to a specific id
	public Cursor queryEventById(int eventId, String[] projection)
	{
	       // Constructs a new query builder and sets its table name
	       SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
	       qb.setTables(Event.EventItem.TABLE_NAME);
	       qb.appendWhere(Event.EventItem.COLUMN_NAME_ID +    // the name of the ID column
	    	        "=" +
	    	        eventId);
	       SQLiteDatabase db = mDBHelper.getReadableDatabase();
	       return qb.query(db, projection, null, null, null, null, null);
	}
	
	//Inserts an event
	public long insertEvent(ContentValues values)
	{
		
		SQLiteDatabase db = mDBHelper.getWritableDatabase();
		
		return db.insert(Event.EventItem.TABLE_NAME, null, values);
		
	}
	
	public long updateEvent(int eventId, ContentValues values)
	{
		
		int count;
		SQLiteDatabase db = mDBHelper.getWritableDatabase();
		
		String where =
                Event.EventItem.COLUMN_NAME_ID +                              // The ID column name
                " = " +  eventId;
		
	       
	       count = db.update(
	               Event.EventItem.TABLE_NAME, // The database table name.
	               values,                   // A map of column names and new values to use.
	               where,               // The final WHERE clause to use
	                                    // placeholders for whereArgs
	               null                 // The where clause column values to select on, or
	                                    // null if the values are in the where argument.
	           );
	       return count;
	       
	}
	
	public int deleteEvent(int id) {

		String finalWhere =
	            Event.EventItem.COLUMN_NAME_ID +                              // The ID column name
	            " = " +                                          // test for equality
	            id;
	        SQLiteDatabase db = mDBHelper.getWritableDatabase();
		    // Performs the delete.
		    int count = db.delete(
		        Event.EventItem.TABLE_NAME,  // The database table name.
		        finalWhere,                // The final WHERE clause
		        null                  // The incoming where clause values.
		    );
			return count;
    }	
	
	public int deleteAllEvents()
	{
		SQLiteDatabase db = mDBHelper.getWritableDatabase();
		return (db.delete(Event.EventItem.TABLE_NAME, "1", null));		
	}
}
