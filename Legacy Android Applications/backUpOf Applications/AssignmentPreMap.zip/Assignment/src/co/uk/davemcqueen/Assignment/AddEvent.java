package co.uk.davemcqueen.Assignment;

import android.app.Activity;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import android.app.DatePickerDialog;

import java.io.IOException;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class AddEvent extends Activity {

	DAO dao;
	boolean updating = false;
	private static final int DATE_DIALOG_ID = 1;
	private static final int TIME_DIALOG_ID = 2;
	int day, month, year; //the values for the date & date picker
	int hour, minute; //the values for the time & time picker
	double lng = 0;//variables to store the long & lat coordinates.
	double lat = 0;
	String strLocation;
	boolean includeLocation = false; //if the user clicks to include location, this will enable and save the location to the DB
	DatePicker datePicker;
	TimePicker timePicker;
	String date;
	String time;
	private String provider;
	String locationFormat;
	SharedPreferences prefs;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.addevent);
		dao = new DAO(this); //Initalise the dao for database access
		
		//Define the visual fields and handlers
		final TextView newEventName = (TextView)findViewById(R.id.newEvent_editEventName);
		final TextView newEventDescription = (TextView)findViewById(R.id.newEvent_editDescription);
		final TextView newEventDate = (TextView)findViewById(R.id.newEvent_txtDate);
		final TextView newEventTime = (TextView)findViewById(R.id.newEvent_txtTime);
		final TextView newEventLocationtxt = (TextView)findViewById(R.id.newEvent_txtLocation);
		final TextView locationTag = (TextView) findViewById(R.id.newEvent_tagLocation);
		final Button newEventbtnGet = (Button) findViewById(R.id.newEvent_btnGetLocation);
		final Button newEventbtnMap = (Button) findViewById(R.id.newEvent_showMap);
		final Bundle extras = getIntent().getExtras();
		CheckBox newEventLocation = (CheckBox)findViewById(R.id.newEvent_checkLocation);
		
		//hid the visibility of the location fields until selected
		newEventLocationtxt.setVisibility(View.GONE);
		locationTag.setVisibility(View.GONE);
		newEventbtnGet.setVisibility(View.GONE);
		newEventbtnMap.setVisibility(View.GONE);
		
		//Get the default shared preferences
		prefs = PreferenceManager.getDefaultSharedPreferences(this);
		locationFormat = prefs.getString("location_format", null);
		
		
		//Acquire the calendar date & time of the current date.
		Calendar today = Calendar.getInstance();
		year = today.get(Calendar.YEAR);
		month = today.get(Calendar.MONTH);
		day = today.get(Calendar.DAY_OF_MONTH);
		hour = today.get(Calendar.HOUR_OF_DAY);
		minute = today.get(Calendar.MINUTE);
		
		date = (year + "/" + (month+1) + "/" + day);
		newEventDate.setText(day + "/" + month + "/" + year);
		String hourtxt = String.valueOf(hour);
		String minutetxt = String.valueOf(minute);
		if(hour < 10)
		{
			hourtxt = (0 + String.valueOf(hour));
		}
		if (minute < 10)
		{
			minutetxt = (0 + String.valueOf(minute));
		}
		newEventTime.setText(hourtxt + ":" + minutetxt);
		
		final LocationManager mlocManager= (LocationManager)getSystemService(Context.LOCATION_SERVICE);
		final LocationListener mlocListener = new MyLocationListener(); //implement a location listener, using the MyLocationListenerClass
		Criteria criteria = new Criteria();
		criteria.setAccuracy(2); //Sets a medium accuracy (100 - 500 meters accurate)
		provider = mlocManager.getBestProvider(criteria, false);
		
		
		//---If information has been passed into the intent, then an update is being performed.
		//--- Load that information into memory and display
		if (extras != null)
		{
			String[] projection = {Event.EventItem.COLUMN_NAME_EVENT, Event.EventItem.COLUMN_NAME_DESCRIPTION,
					Event.EventItem.COLUMN_NAME_DATE, Event.EventItem.COLUMN_NAME_TIME, Event.EventItem.COLUMN_NAME_LOCATION};
			
			Cursor c = dao.queryEventById(extras.getInt("id"), projection);
			while (c.moveToNext())
			{
				newEventName.setText(c.getString(0));
				newEventDescription.setText(c.getString(1));
				date = (c.getString(2));
				time = (c.getString(3));
				newEventTime.setText(time);
				strLocation = (c.getString(4));
			}
			if (date.contains("/"))
			{
				//splits the date string to put values into the datePicker dialog
				String[] dateValues = date.split("/");
				year = Integer.parseInt(dateValues[0]);
				month = Integer.parseInt(dateValues[1]);
				day = Integer.parseInt(dateValues[2]);
				newEventDate.setText(day + "/" + month + "/" + year);//sets the date filed to display the saved date
				month--;
			}
			if (time.contains(":"))
			{	//splits the time values down to put into the timePicker dialog
				String[] timeValues = time.split(":");
				hour = (Integer.parseInt(timeValues[0]));
				minute = (Integer.parseInt(timeValues[1]));
			}
			if (strLocation != null && strLocation.contains(", "))
			{	//splits the location string down into the relevant format
				String[] locationValues = strLocation.split(", ");
				
				lat = Double.parseDouble(locationValues[0]);
				lng = Double.parseDouble(locationValues[1]);
				
				if (lat != 0 && lng != 0)
				{ //checks that a location has been set and displays that location, else leave blank
					newEventLocation.setChecked(true);
					newEventLocationtxt.setVisibility(View.VISIBLE);
					locationTag.setVisibility(View.VISIBLE);
					newEventbtnGet.setVisibility(View.VISIBLE);
					newEventbtnMap.setVisibility(View.VISIBLE);
					includeLocation = true;
					
					//Get the desired location format from the shared preferences
					
					geoCode(lat, lng, locationFormat);
					
				}
				
			}
			   
			updating = true; //tell the activity we are performing an update, not a new event.
		}
		newEventbtnGet.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				mlocManager.requestLocationUpdates(provider, 0, 10, mlocListener);
			}
		});
		newEventTime.setOnFocusChangeListener(new OnFocusChangeListener(){
			@Override
			public void onFocusChange(View arg0, boolean arg1) {
				// TODO Auto-generated method stub
				showDialog(TIME_DIALOG_ID);
				newEventTime.clearFocus();
			}
		});

		
		newEventLocation.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (((CheckBox)v).isChecked())
				{
					includeLocation = true;
					newEventLocationtxt.setVisibility(View.VISIBLE);
					locationTag.setVisibility(View.VISIBLE);
					newEventbtnGet.setVisibility(View.VISIBLE);
					newEventbtnMap.setVisibility(View.VISIBLE);
					
				} else if(!((CheckBox)v).isChecked())
				{
					includeLocation = false;
					newEventLocationtxt.setVisibility(View.GONE);
					locationTag.setVisibility(View.GONE);
					newEventbtnGet.setVisibility(View.GONE);
					newEventbtnMap.setVisibility(View.GONE);
					mlocManager.removeUpdates(mlocListener);
				}
			}
		});
		if (prefs.getBoolean("display_location", false) && updating == false)
		{
			newEventLocation.setChecked(true);
			includeLocation = true;
			newEventLocationtxt.setVisibility(View.VISIBLE);
			locationTag.setVisibility(View.VISIBLE);
			newEventbtnGet.setVisibility(View.VISIBLE);
			newEventbtnMap.setVisibility(View.VISIBLE);
			
		}
		
		
		//When the users clicks on the date box,a datePicker dialog is displayed.
		//This ensures that the same date format is used consistently.
		newEventDate.setOnFocusChangeListener(new OnFocusChangeListener(){
			@Override
			public void onFocusChange(View arg0, boolean arg1) {
				// TODO Auto-generated method stub
				showDialog(DATE_DIALOG_ID);
				newEventDate.clearFocus();
			}
		});
		
		Button btnSave = (Button) findViewById(R.id.newEvent_btnSave);
		btnSave.setOnClickListener(new OnClickListener()
		{
			public void onClick(View arg0){
				
				if (updating == false)
				{//if the event is a new event

					ContentValues inputValues = new ContentValues();
					inputValues.put(Event.EventItem.COLUMN_NAME_EVENT, newEventName.getText().toString());
					inputValues.put(Event.EventItem.COLUMN_NAME_DESCRIPTION, newEventDescription.getText().toString());
					inputValues.put(Event.EventItem.COLUMN_NAME_DATE, date);
					inputValues.put(Event.EventItem.COLUMN_NAME_TIME, newEventTime.getText().toString());
					if (includeLocation == true)
					{
						inputValues.put(Event.EventItem.COLUMN_NAME_LOCATION, (String.valueOf(lat) + ", " + String.valueOf(lng)));
					} else if (includeLocation = false){
						inputValues.put(Event.EventItem.COLUMN_NAME_LOCATION, ("0, 0"));
						//if the user doesnt want to store their location, enter blank values
					}
				long position = dao.insertEvent(inputValues);
						
				displayToast("Inserted at position " + String.valueOf(position));
				}else{
				//if the event is one to be edited
					ContentValues values = new ContentValues();
					values.put(Event.EventItem.COLUMN_NAME_EVENT, newEventName.getText().toString());
					values.put(Event.EventItem.COLUMN_NAME_DESCRIPTION, newEventDescription.getText().toString());
					values.put(Event.EventItem.COLUMN_NAME_DATE, date);
					values.put(Event.EventItem.COLUMN_NAME_TIME, newEventTime.getText().toString());
					if (includeLocation == true)
					{
						values.put(Event.EventItem.COLUMN_NAME_LOCATION, (String.valueOf(lat) + ", " + String.valueOf(lng)));
					} else if (includeLocation == false)
					{
						values.put(Event.EventItem.COLUMN_NAME_LOCATION, ("0, 0"));
						//if the user doesnt want to store their location, enter blank values
					}
					long updateAmount = dao.updateEvent(extras.getInt("id"), values);
					displayToast("Updated " + updateAmount + " item(s)");
				}
				finish();
			}
		});
	}
	
	public void displayToast(String message)
	{
		Toast.makeText(this, message, Toast.LENGTH_LONG).show();
		
	}

	@Override
	@Deprecated
	protected Dialog onCreateDialog(int id) {
		// TODO Auto-generated method stub
		switch(id) {
		case DATE_DIALOG_ID:
			return new DatePickerDialog(
					this, mDateSetListener, year, month, day);
		case TIME_DIALOG_ID:
			return new TimePickerDialog(
					this, mTimeSetListener, hour, minute, false);
	}
	return null;
	}
	
	//function to display a timePicker dialog.
	private TimePickerDialog.OnTimeSetListener mTimeSetListener = 
 	new TimePickerDialog.OnTimeSetListener() {
		@Override
		public void onTimeSet(TimePicker view, int hourOfDay, int newMinute) {
			// TODO Auto-generated method stub
			hour = hourOfDay;
			minute = newMinute;
			final TextView newEventTime = (TextView)findViewById(R.id.newEvent_txtTime);
			
			String hourtxt = String.valueOf(hour);
			String minutetxt = String.valueOf(minute);
			if(hour < 10)
			{
				hourtxt = (0 + String.valueOf(hour));
			}
			if (minute < 10)
			{
				minutetxt = (0 + String.valueOf(minute));
			}
			time = (hourtxt + ":" + minutetxt);
			newEventTime.setText(time);
		}
	};
	
	//Function to display a datePicker dialog
 
	private DatePickerDialog.OnDateSetListener mDateSetListener =
    		new DatePickerDialog.OnDateSetListener()
    {
    	public void onDateSet(
    			DatePicker view, int newYear, int monthOfYear, int dayOfMonth)
    	{
    		year = newYear;
    		month = monthOfYear;
    		day = dayOfMonth;
    		
			final TextView newEventDate = (TextView)findViewById(R.id.newEvent_txtDate);
			date = day + "/" + (month+1) + "/" + year;
			newEventDate.setText(date);
			date = (year + "/" + (month+1) + "/" + day);
		}
    };

	
    
    /*
     * (non-Javadoc)
     * @see android.location.LocationListener#onLocationChanged(android.location.Location)
     */
   public class MyLocationListener implements LocationListener {

		@Override
		public void onLocationChanged(Location location) {
			// TODO Auto-generated method stub
			
			TextView newEventLocationtxt = (TextView)findViewById(R.id.newEvent_txtLocation);
			lat = location.getLatitude();
			lng = location.getLongitude();
			strLocation = (String.valueOf(lat) + ", " + String.valueOf(lng));
			geoCode(lat, lng, locationFormat);
		}

		@Override
		public void onProviderDisabled(String provider) {
			// TODO Auto-generated method stub
			
			//add function to prompt the user to enable gps
		}

		@Override
		public void onProviderEnabled(String provider) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {
			// TODO Auto-generated method stub
			
		}
	}
   
   public void geoCode(double lat, double lng, String format)
   {
	   final TextView newEventLocationtxt = (TextView)findViewById(R.id.newEvent_txtLocation);
	   Geocoder geoCoder = new Geocoder(getBaseContext(), Locale.getDefault());
	   
	   if (!locationFormat.equalsIgnoreCase("GPS Co-ordinates"))
	   {
		   try {
			   List<Address> addresses = geoCoder.getFromLocation(lat, lng, 1);
			   
			   if (addresses.size() > 0)
			   {
				   String add = "";
				   if (format.equalsIgnoreCase("Street address"))
				   {
					   for (int i = 0; i < addresses.get(0).getMaxAddressLineIndex(); i++)
					   {
						   add += addresses.get(0).getAddressLine(i) + "\n";
					   }
				   }  else if (format.equalsIgnoreCase("City"))
				   {
					   add = addresses.get(0).getLocality();
				   }
				   newEventLocationtxt.setText(add);
			   }
		   } catch (IOException e) {
			   // TODO Auto-generated catch block
			   e.printStackTrace();
		   }
	   }else
	   {
		 newEventLocationtxt.setText(strLocation);
	   }
	 
   }
   @Override
protected void onResume() {
	// TODO Auto-generated method stub
	super.onResume();
	locationFormat = prefs.getString("location_format", null);
	geoCode(lat, lng, locationFormat);
}

public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.addevent_optionmenu, menu);
		
		return true;
	}
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		
		switch (item.getItemId()){
			case R.id.menu_settings:
				//Add a new expense
				Intent i = new Intent(getBaseContext(), ShowPreferencesActivity.class);
				startActivity(i);
				return true;
			default:
				return super.onOptionsItemSelected(item);
		}
	}
   
}



