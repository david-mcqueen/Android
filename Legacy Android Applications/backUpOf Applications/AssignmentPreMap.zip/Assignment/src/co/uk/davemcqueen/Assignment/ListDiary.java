package co.uk.davemcqueen.Assignment;

import android.os.Bundle;
import android.preference.PreferenceManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.util.Log;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.app.ListActivity;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

public class ListDiary extends ListActivity {

	private static final String TAG = "MAIN";
	
	DAO dao;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
	
		super.onCreate(savedInstanceState);
		//csll to populate the screen with all the db info
		populateList();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.option_menu, menu);
		
		return true;
	}
	
	public void displayToast(String message)
	{
		Toast.makeText(this, message, Toast.LENGTH_LONG).show();
		
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		
		switch (item.getItemId()){
			case R.id.menu_add:
				
				//Add a new expense
				Intent i = new Intent(getBaseContext(), AddEvent.class);
				startActivity(i);
				return true;
				
			case R.id.menu_settings:
				//open up the options menu
				Intent settings = new Intent(this, ShowPreferencesActivity.class);
				startActivity(settings);
				return true;
				
			case R.id.menu_deleteAll:
				//delete all the events
				
				int rowsDeleted = dao.deleteAllEvents();
				if ( rowsDeleted > 0)
				{
				displayToast("Success! " + String.valueOf(rowsDeleted) + " row(s) deleted");
				populateList();
				}
			default:
					return super.onOptionsItemSelected(item);
		}
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		populateList();
	}
	
	//a function to populate the listView with all the information in the DB
	public void populateList()
	{
		dao = new DAO(this);
		String[] projection = {Event.EventItem.COLUMN_NAME_ID, Event.EventItem.COLUMN_NAME_EVENT, Event.EventItem.COLUMN_NAME_DESCRIPTION};
		Cursor c = dao.queryAllEvents(projection);
		
		//Populate a lost view with all the events in the DB
		@SuppressWarnings("deprecation")
		SimpleCursorAdapter adapter = new SimpleCursorAdapter(
				this,
				android.R.layout.simple_list_item_1,
				c,
				new String[] {Event.EventItem.COLUMN_NAME_EVENT},
				new int[] {android.R.id.text1});
		
		ListView listView = getListView();
		listView.setChoiceMode(1);
		listView.setAdapter(adapter);
		registerForContextMenu(listView);
		
		
		//if an event is clicked on, open up the svreen to edit the event
		listView.setOnItemClickListener(new OnItemClickListener(){
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position,
					long id) {
				// TODO Auto-generated method stub
				editExpenseItem(position, id);
			}
		});
	}
	
	private void editExpenseItem(int position, long id) {

		//update the list to highlight the selected item and show the data.
		getListView().setItemChecked(position, true);
		
		long checkedItems[] = getListView().getCheckedItemIds();

	  Log.d(TAG, "Launching ExpenseEntryActivtiy");
		
  	  Intent intent = new Intent(ListDiary.this, AddEvent.class);
  	  intent.setData(getIntent().getData()); // Make the base CP available in the target action
  	  intent.putExtra("id", ((int)(id)));
  	  startActivity(intent);			

	}
	
	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
			ContextMenuInfo menuInfo) {
		getMenuInflater().inflate(R.menu.long_menu, menu);	
	}

	@Override
	public boolean onContextItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		AdapterContextMenuInfo info = (AdapterContextMenuInfo) item.getMenuInfo();
		switch (item.getItemId()){
		case R.id.menu_event_delete:
			//deletes the item
			long temp = dao.deleteEvent((int)info.id);
			displayToast("Deleted " + String.valueOf(temp) + " item(s)");
			populateList();
			return true;
			
		case R.id.menu_event_edit:
			//open up edit menu for that item
			
			Intent intent = new Intent(ListDiary.this, AddEvent.class);
		  	  intent.setData(getIntent().getData()); // Make the base CP available in the target action
		  	  intent.putExtra("id", ((int)info.id));
		  	  startActivity(intent);
			return true;
		case R.id.share_facebook:
			displayToast("This will be shared on facebook");
			return true;
		case R.id.share_twitter:
			displayToast("This will be shared on twitter");
			return true;
		default:
				return super.onContextItemSelected(item);
	}
	}
	
	private void storePreferences(String name, String value)
	{
		SharedPreferences.Editor editor = getPreferences(MODE_PRIVATE).edit();
		editor.putString(name, value);
		editor.commit();
	}
	
	private String getPreferences(String name)
	{
		SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
		return (prefs.getString(name, null));
	}


}
